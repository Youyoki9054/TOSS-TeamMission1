# D3 Dot Plot

You can view this notebook by running a web server in this directory and
visiting it as a webpage. For example:

```sh
python -m SimpleHTTPServer
# Then, visit http://localhost:8000.
```

Or, use the [Notebook Runtime API](https://github.com/observablehq/notebook-runtime) to
integrate directly with d3-dot-plot.js, which contains the notebook compiled as an
ES module.

*Exported from version 518 of [D3 Dot Plot](https://beta.observablehq.com/@mbostock/d3-dot-plot) on observablehq.com.*