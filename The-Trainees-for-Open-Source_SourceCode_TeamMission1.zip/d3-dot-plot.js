// URL: https://beta.observablehq.com/@mbostock/d3-dot-plot
// Title: D3 Dot Plot
// Author: Mike Bostock (@mbostock)
// Version: 518
// Runtime version: 1

const m0 = {
  id: "83dac3a4bf2a6b15@518",
  variables: [
    {
      inputs: ["md"],
      value: (function(md){return(
md`# D3 Dot Plot

<h2> The Trainees for Open Source </h2>

The percentage of protocols demographics by time zome. Data: [American Community Survey](/@mbostock/working-with-the-census-api)`
)})
    },
    {
      name: "viewof primary",
      inputs: ["html","variables"],
      value: (function(html,variables)
{
  const form = html`<form><label>Order by <select name=i>${Array.from(variables, ([key], i) => html`
  <option value=${i}>${key}</option>`).reverse()}
</select></label></form>`;
  form.oninput = () => form.value = +form.i.value;
  form.oninput();
  return form;
}
)
    },
    {
      name: "primary",
      inputs: ["Generators","viewof primary"],
      value: (G, _) => G.input(_)
    },
    {
      name: "chart",
      inputs: ["d3","DOM","width","height","data","x","y","color","yAxis","legend"],
      value: (function(d3,DOM,width,height,data,x,y,color,yAxis,legend)
{
  const svg = d3.select(DOM.svg(width, height));

  const g = svg.append("g")
      .attr("text-anchor", "middle")
      .style("font", "10px sans-serif")
    .selectAll("g")
    .data(data)
    .enter().append("g")
      .attr("transform", (d, i) => `translate(${x(data.names[i])},0)`);

  g.append("line")
      .attr("stroke", "#ccc")
      .attr("y1", d => y(d3.min(d)))
      .attr("y2", d => y(d3.max(d)));

  g.append("g")
    .selectAll("circle")
    .data(d => d)
    .enter().insert("circle", "circle")
      .attr("cy", d => y(d))
      .attr("fill", (d, i) => color(data.keys[i]))
      .attr("r", 3.5);

  g.append("text")
      .attr("dy", "1.5em")
      .attr("y", d => y(d[d.length - 1]))
      .text((d, i) => data.names[i]);

  svg.append("g")
      .call(yAxis);

  svg.append("g")
      .call(legend);

  function update(primary) {
    // Compute the desired order based on the selected age group.
    x.domain(d3.permute(data.names, d3.range(data.length)
        .sort((i, j) => data[j][primary] - data[i][primary])));

    // Transition the columns to their new position.
    g.transition()
        .delay((d, i) => i * 10)
        .attr("transform", (d, i) => `translate(${x(data.names[i])},0)`)
  }

  return Object.assign(svg.node(), {update});
}
)
    },
    {
      inputs: ["chart","primary"],
      value: (function(chart,primary){return(
chart.update(primary)
)})
    },
	// The "variables" signifies the "protocols"
	// The "variables" which used to have the value as age group, has the value as the names of protocols 
    {
      name: "variables",
      value: (function(){return(
new Map([["TCP", "01"], ["RPC_NETLOGON", "02"], ["TLSv1.2", "03"], ["NBNS", "04"], ["SMB2", "05"], ["LDAP", "06"], ["DNS", "07"], ["HTTP", "08"], ["KRB5", "09"]])
)})
    },
	// The "states" signifies the "times"
	// The "states" which used to have the value as the names of the United States, has the value as the time zones. 
    {
      name: "states",
      value: (function(){return(
new Map([["01", "7~10"], ["02", "10~15"], ["03", "15~20"], ["04", "20~25"], ["05", "25~30"], ["06", "30~35"], ["07", "35~40"], ["08", "40~45"], ["09", "45~50"]])
)})
    },
    {
      name: "data",
      inputs: ["d3","variables","states"],
      value: (async function(d3,variables,states)
{
  // The code lines which has the contents that called up the existing data file to parse the necessary elements.
  // The constant variable "values" has the percentage of protocol communications by time zone.
  const values = [[ 0.167296548249 , 0.768959435626 , 0.0 , 0.00907029478458 , 0.0151171579743 , 0.0138573948098 , 0.00957420005039 , 0.00403124212648 , 0.0120937263794 ] ,
[ 0.673913043478 , 0.0 , 0.159420289855 , 0.108695652174 , 0.0 , 0.0 , 0.0144927536232 , 0.0434782608696 , 0.0 ] ,
[ 0.676767676768 , 0.0 , 0.222222222222 , 0.0606060606061 , 0.0 , 0.0 , 0.0 , 0.040404040404 , 0.0 ] ,
[ 0.55525606469 , 0.0 , 0.269541778976 , 0.0242587601078 , 0.0350404312668 , 0.0512129380054 , 0.0431266846361 , 0.0161725067385 , 0.00539083557951 ] ,
[ 0.676767676768 , 0.0 , 0.222222222222 , 0.0606060606061 , 0.0 , 0.0 , 0.0 , 0.040404040404 , 0.0 ] ,
[ 0.704545454545 , 0.0 , 0.25 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0454545454545 , 0.0 ] ,
[ 0.612068965517 , 0.0 , 0.189655172414 , 0.0646551724138 , 0.0560344827586 , 0.0 , 0.0431034482759 , 0.0344827586207 , 0.0 ] ,
[ 0.893767705382 , 0.0 , 0.0982058545798 , 0.0042492917847 , 0.0 , 0.0 , 0.000944287063267 , 0.0028328611898 , 0.0 ] ,
[ 0.67 , 0.0 , 0.22 , 0.07 , 0.0 , 0.0 , 0.0 , 0.04 , 0.0 ]];
  
  // The constant variable "names" has the time zone("values" above) as in the 'array' structure.
  const names = Array.from(states.values());
  
  // Lastly,decorate the returned object with additional fields.
  return Object.assign(values, {
    keys: Array.from(variables.keys()),
    names: names
  });
}
)
    },
    {
      name: "x",
      inputs: ["d3","data","margin","width"],
      value: (function(d3,data,margin,width){return(
d3.scalePoint()
    .domain(data.names)
    .range([margin.left, width - margin.right])
    .padding(1)
)})
    },
    {
      name: "y",
      inputs: ["d3","data","height","margin"],
      value: (function(d3,data,height,margin){return(
d3.scaleLinear()
    .domain([0, d3.max(data, d => d3.max(d))])
    .rangeRound([height - margin.bottom, margin.top])
)})
    },
    {
      name: "color",
      inputs: ["d3","data"],
      value: (function(d3,data){return(
d3.scaleOrdinal()
    .unknown("#ccc")
    .domain(data.keys)
    .range(d3.quantize(t => d3.interpolateSpectral(t * 0.8 + 0.1), data.keys.length).reverse())
)})
    },
    {
      name: "yAxis",
      inputs: ["margin","d3","y"],
      value: (function(margin,d3,y){return(
g => g
    .attr("transform", `translate(${margin.left},0)`)
    .call(d3.axisLeft(y).ticks(null, "%"))
    .call(g => g.selectAll(".domain").remove())
)})
    },
    {
      name: "legend",
      inputs: ["width","margin","data","color"],
      value: (function(width,margin,data,color){return(
svg => {
  const g = svg
      .attr("font-family", "sans-serif")
      .attr("font-size", 10)
      .attr("text-anchor", "end")
      .attr("transform", `translate(${width},${margin.top})`)
    .selectAll("g")
    .data(data.keys.slice().reverse())
    .enter().append("g")
      .attr("transform", (d, i) => `translate(0,${i * 20})`);

  g.append("rect")
      .attr("x", -19)
      .attr("width", 19)
      .attr("height", 19)
      .attr("fill", color);

  g.append("text")
      .attr("x", -24)
      .attr("y", 9.5)
      .attr("dy", "0.35em")
      .text(d => d);
}
)})
    },
    {
      name: "height",
      value: (function(){return(
600
)})
    },
    {
      name: "margin",
      value: (function(){return(
{top: 10, right: 20, bottom: 20, left: 40}
)})
    },
    {
      name: "d3",
      inputs: ["require"],
      value: (function(require){return(
require("d3@5")
)})
    }
  ]
};

const notebook = {
  id: "83dac3a4bf2a6b15@518",
  modules: [m0]
};

export default notebook;
